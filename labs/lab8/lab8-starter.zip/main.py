import csv
import codecs
import requests


def fetch_data_from_url(url):
    """
    Fetches a CSV file from the web.

    Parameters:
        url (str): The URL of a CSV file.

    Returns:
        (list of list of values): a list of lists representing CSV rows.
    """
    r = requests.get(url)
    text = codecs.iterdecode(r.iter_lines(), 'utf-8')
    reader = csv.reader(text, delimiter=',')
    data = list(reader)
    return data


def to_dict(data):
    """
    Converts a list of list of values into a dictionary.

    This function expects a list of list of values that represents a CSV
    file. The first item of data (data[0]) is the *header* of the CSV file.
    The header is used as the keys to a dictionary that is created for
    each subsequent row in data (data[1:]).

    Parameters:
        data (list of list of values): data from a CSV file.

    Returns:
        (list of dictionaries): a list of dictionaries of olympic medal data.
    """
    xs = []
    # TODO
    return xs


def count_countries(medals):
    """
    Returns the number of countries in the medals data.

    Parameters:
        medals (list of dict): a list of dictionaries of olympic medal data.

    Returns:
        (int): the number of countries awarded medals.
    """
    countries = set()
    # TODO
    return len(countries)


def medals_by_gender(medals):
    """
    Returns the number of medals awarded by gender.

    Parameters:
        medals (list of dict): a list of dictionaries of olympic medal data.

    Returns:
        (dict): a dictionary mapping gender to number of medals awarded.
    """
    gender = {}
    # TODO
    return gender


def medals_by_country(medals):
    """
    Returns the number of medals for each country.

    Parameters:
        medals (list of dict): a list of dictionaries of olympic medal data.

    Returns:
        (dict): a dictionary mapping countries to number of medals awarded.
    """
    countries = {}
    # TODO
    return countries


def country_with_most_medals(country_medals):
    """
    Returns the country with the most medals.

    Parameters:
        country_medals (dict): a dictionary mapping countries to # of medals.

    Returns:
        (int): the country with the most medals.
    """
    country = '😕'
    # TODO
    return country


if __name__ == '__main__':
    data = fetch_data_from_url('http://winterolympicsmedals.com/medals.csv')
    print(data[0])
